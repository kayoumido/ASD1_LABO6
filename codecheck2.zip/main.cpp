#include "Mouchard.h"

using namespace std; 

int main() {
  
   Int* p1  = new Int();
   Int* p2  = new Int(5);
   Int* p3  = new Int(*p2);
   Int* p4  = new Int(move(*p3));
      *p1 = *p2;
      *p1 = move(*p4);
   
   delete p4;
   delete p3;
   delete p2;
   delete p1;
}