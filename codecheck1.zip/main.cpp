#include "Mouchard.h"

using namespace std; 

int main() {
    Int p1;             // DC
    Int p2 = 5;         // IC
    Int p3 = p2;        // CC
    Int p4 = move(p3);  // MC
    p1 = p2;            // C=
    p1 = move(p4);      // M=

}